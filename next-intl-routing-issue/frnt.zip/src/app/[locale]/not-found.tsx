// Note that `app/[locale]/[...rest]/page.tsx`
// is necessary for this page to render.

export {default} from '@/components/NotFoundPage';
